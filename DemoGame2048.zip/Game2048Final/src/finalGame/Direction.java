package finalGame;
//Tài liệu tham khảo: FaTal Cubez
public enum Direction {

		LEFT,
		RIGHT,
		UP,
		DOWN
}

