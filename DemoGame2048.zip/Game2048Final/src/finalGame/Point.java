package finalGame;

public class Point {
	public int col;
	public int row;

	public Point(int row, int col) {
		this.row = row;
		this.col = col;
	}

}
